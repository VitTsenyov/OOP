#ifndef FUNC_H
#define FUNC_H

double f(double x);
double f_prime(double x);

#endif